package com.saad.spice;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.util.Log;
import androidx.core.content.FileProvider;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int RC_GOOGLE_SIGN_IN = 7101;
    private WebView web;
    private FrameLayout root;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private FirebaseAuth auth;
    private FirebaseFirestore firestore;
    private GoogleSignInClient googleClient;
    private boolean pageLoaded = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FirebaseApp.initializeApp(this);
        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail().build();
        googleClient = GoogleSignIn.getClient(this, options);

        web = new WebView(this);
        web.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new AppBridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                dispatchAuthState();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/"))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception ignored) { view.loadUrl(url); }
                    return true;
                }
                return false;
            }
        });
        root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void dispatchAuthState() {
        if (!pageLoaded || web == null) return;
        if (auth.getCurrentUser() == null) web.evaluateJavascript("onNativeAuth(null,'')", null);
        else {
            String uid = JSONObject.quote(auth.getCurrentUser().getUid());
            String email = JSONObject.quote(auth.getCurrentUser().getEmail() == null ? "" : auth.getCurrentUser().getEmail());
            web.evaluateJavascript("onNativeAuth(" + uid + "," + email + ")", null);
        }
    }

    private class AppBridge {
        @JavascriptInterface public void signInGoogle() {
            handler.post(() -> startActivityForResult(googleClient.getSignInIntent(), RC_GOOGLE_SIGN_IN));
        }
        @JavascriptInterface public void signOutGoogle() {
            handler.post(() -> {
                auth.signOut();
                googleClient.signOut().addOnCompleteListener(task -> dispatchAuthState());
            });
        }
        @JavascriptInterface public void loadCloudData() {
            String uid = auth.getCurrentUser() == null ? null : auth.getCurrentUser().getUid();
            if (uid == null) { dispatchAuthState(); return; }
            userDataRef(uid).get().addOnSuccessListener(snapshot -> {
                String payload = snapshot.exists() ? snapshot.getString("payload") : null;
                String js = "onCloudData(" + JSONObject.quote(payload == null ? "" : payload) + ")";
                handler.post(() -> web.evaluateJavascript(js, null));
            }).addOnFailureListener(e -> {
                Log.e("SAAD_FIRESTORE", "Load failed", e);
                handler.post(() -> web.evaluateJavascript("onCloudDataError()", null));
            });
        }
        @JavascriptInterface public void saveCloudData(String json) {
            String uid = auth.getCurrentUser() == null ? null : auth.getCurrentUser().getUid();
            if (uid == null || json == null) { handler.post(() -> web.evaluateJavascript("onCloudSaved(false)", null)); return; }
            try {
                new JSONObject(json); // validate JSON before writing
                Map<String, Object> data = new HashMap<>();
                data.put("payload", json);
                data.put("updatedAt", com.google.firebase.firestore.FieldValue.serverTimestamp());
                userDataRef(uid).set(data, SetOptions.merge())
                    .addOnSuccessListener(v -> handler.post(() -> web.evaluateJavascript("onCloudSaved(true)", null)))
                    .addOnFailureListener(e -> {
                        Log.e("SAAD_FIRESTORE", "Save failed", e);
                        handler.post(() -> web.evaluateJavascript("onCloudSaved(false)", null));
                    });
            } catch (Exception e) {
                Log.e("SAAD_FIRESTORE", "Invalid payload", e);
                handler.post(() -> web.evaluateJavascript("onCloudSaved(false)", null));
            }
        }
        @JavascriptInterface public void sharePdf(String html, String filename) {
            handler.post(() -> createAndSharePdf(html, filename));
        }
    }

    private DocumentReference userDataRef(String uid) {
        return firestore.collection("users").document(uid).collection("appData").document("main");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_GOOGLE_SIGN_IN) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                auth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) dispatchAuthState();
                    else showAuthError(task.getException() == null ? "تعذر تسجيل الدخول." : task.getException().getMessage());
                });
            } catch (ApiException e) { showAuthError("تعذر تسجيل الدخول باستخدام Google. رمز الخطأ: " + e.getStatusCode()); }
        }
    }

    private void showAuthError(String message) {
        String safe = JSONObject.quote(message == null ? "حدث خطأ في تسجيل الدخول." : message);
        handler.post(() -> web.evaluateJavascript("setAuthMessage(" + safe + ")", null));
    }

    private void createAndSharePdf(String html, String filename) {
        try {
            final int width = 794;
            WebView pdfView = new WebView(this);
            pdfView.setBackgroundColor(Color.WHITE);
            pdfView.getSettings().setJavaScriptEnabled(true);
            pdfView.getSettings().setDefaultTextEncodingName("UTF-8");
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, 20000);
            pdfView.setAlpha(0.01f);
            pdfView.setTranslationX(-10000f);
            root.addView(pdfView, lp);
            pdfView.setWebViewClient(new WebViewClient() {
                private boolean handled = false;
                @Override public void onPageFinished(WebView view, String url) {
                    if (handled) return;
                    handled = true;
                    view.postDelayed(() -> view.evaluateJavascript(
                        "Math.max(document.body ? document.body.scrollHeight : 0, document.documentElement ? document.documentElement.scrollHeight : 0)", result -> {
                            try {
                                String raw = result == null ? "" : result.replace("\"", "").trim();
                                int measured = (int) Double.parseDouble(raw);
                                int height = Math.max(900, Math.min(20000, measured + 60));
                                view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
                                view.layout(0, 0, width, height);
                                view.postDelayed(() -> writePdfAndShare(view, width, height, filename), 60);
                            } catch (Exception e) {
                                Log.e("SAAD_DATA_PDF", "Failed to measure PDF content", e);
                                root.removeView(view); view.destroy(); shareFailure();
                            }
                        }), 60);
                }
                @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    Log.e("SAAD_DATA_PDF", "PDF WebView error: " + description);
                    root.removeView(view); view.destroy(); shareFailure();
                }
            });
            pdfView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Log.e("SAAD_DATA_PDF", "Unable to start PDF generation", e);
            shareFailure();
        }
    }

    private void writePdfAndShare(WebView view, int contentWidth, int contentHeight, String filename) {
        PdfDocument doc = new PdfDocument();
        try {
            final int pageW = 595, pageH = 842;
            float scale = (float) pageW / contentWidth;
            int pageCssHeight = (int) (pageH / scale);
            int pageCount = Math.max(1, (contentHeight + pageCssHeight - 1) / pageCssHeight);
            for (int n = 0; n < pageCount; n++) {
                PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, n + 1).create());
                Canvas canvas = page.getCanvas(); canvas.drawColor(Color.WHITE); canvas.save();
                canvas.scale(scale, scale); canvas.translate(0, -n * pageCssHeight); view.draw(canvas); canvas.restore(); doc.finishPage(page);
            }
            File dir = new File(getCacheDir(), "pdf"); if (!dir.exists()) dir.mkdirs();
            String safe = (filename == null ? "SAAD_DATA.pdf" : filename).replaceAll("[^a-zA-Z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
            File out = new File(dir, safe); try (FileOutputStream stream = new FileOutputStream(out)) { doc.writeTo(stream); }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
            Intent send = new Intent(Intent.ACTION_SEND); send.setType("application/pdf"); send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, "SAAD SPICES - PDF"); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة ملف PDF عبر"));
        } catch (Exception e) { Log.e("SAAD_DATA_PDF", "Failed to write/share PDF", e); shareFailure(); }
        finally { doc.close(); if (root != null) root.removeView(view); view.destroy(); }
    }

    private void shareFailure() { new android.app.AlertDialog.Builder(this).setMessage("تعذّر إنشاء الملف أو مشاركته. يرجى المحاولة مرة أخرى.").setPositiveButton("حسناً", null).show(); }
    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("handleAndroidBack()", value -> { if (!"true".equals(value)) MainActivity.super.onBackPressed(); });
        else super.onBackPressed();
    }
}
