package com.saad.spice;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.pdf.PrintedPdfDocument;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.CancellationSignal;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.util.Log;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private FrameLayout root;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new PdfBridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/"))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception ignored) { view.loadUrl(url); }
                    return true;
                }
                return false;
            }
        });
        root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class PdfBridge {
        @JavascriptInterface public void sharePdf(String html, String filename) {
            handler.post(() -> createAndSharePdf(html, filename));
        }
        @JavascriptInterface public void shareImage(String html, String filename) {
            handler.post(() -> createAndShareImage(html, filename));
        }
    }

    private void createAndSharePdf(String html, String filename) {
        try {
            final int width = 794;
            WebView pdfView = new WebView(this);
            pdfView.setBackgroundColor(Color.WHITE);
            pdfView.getSettings().setJavaScriptEnabled(false);
            pdfView.getSettings().setDefaultTextEncodingName("UTF-8");
            // Attach the rendering WebView to the window; unattached WebViews can fail
            // to lay out or draw reliably on some Android versions.
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, 20000);
            pdfView.setAlpha(0.01f);
            pdfView.setTranslationX(-10000f);
            root.addView(pdfView, lp);
            pdfView.setWebViewClient(new WebViewClient() {
                private boolean handled = false;
                @Override public void onPageFinished(WebView view, String url) {
                    if (handled) return;
                    handled = true;
                    view.postDelayed(() -> view.evaluateJavascript(
                        "Math.max(document.body ? document.body.scrollHeight : 0, document.documentElement ? document.documentElement.scrollHeight : 0)", result -> {
                            try {
                                String raw = result == null ? "" : result.replace("\"", "").trim();
                                int measured = (int) Double.parseDouble(raw);
                                int height = Math.max(900, Math.min(20000, measured + 60));
                                view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
                                view.layout(0, 0, width, height);
                                view.postDelayed(() -> writePdfAndShare(view, width, height, filename), 150);
                            } catch (Exception e) {
                                Log.e("SAAD_DATA_PDF", "Failed to measure PDF content", e);
                                root.removeView(view); view.destroy(); shareFailure();
                            }
                        }), 150);
                }
                @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    Log.e("SAAD_DATA_PDF", "PDF WebView error: " + description);
                    root.removeView(view); view.destroy(); shareFailure();
                }
            });
            pdfView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Log.e("SAAD_DATA_PDF", "Unable to start PDF generation", e);
            shareFailure();
        }
    }

    private void writePdfAndShare(WebView view, int contentWidth, int contentHeight, String filename) {
        PdfDocument doc = new PdfDocument();
        try {
            final int pageW = 595, pageH = 842;
            float scale = (float) pageW / contentWidth;
            int pageCssHeight = (int) (pageH / scale);
            int pageCount = Math.max(1, (contentHeight + pageCssHeight - 1) / pageCssHeight);
            for (int n = 0; n < pageCount; n++) {
                PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, n + 1).create());
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);
                canvas.save();
                canvas.scale(scale, scale);
                canvas.translate(0, -n * pageCssHeight);
                view.draw(canvas);
                canvas.restore();
                doc.finishPage(page);
            }
            File dir = new File(getCacheDir(), "pdf");
            if (!dir.exists()) dir.mkdirs();
            String safe = (filename == null ? "SAAD_DATA.pdf" : filename).replaceAll("[^a-zA-Z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
            File out = new File(dir, safe);
            try (FileOutputStream stream = new FileOutputStream(out)) { doc.writeTo(stream); }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, "SAAD DATA - PDF");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة ملف PDF عبر"));
        } catch (Exception e) { Log.e("SAAD_DATA_PDF", "Failed to write/share PDF", e); shareFailure(); }
        finally { doc.close(); if (root != null) root.removeView(view); view.destroy(); }
    }


    private void createAndShareImage(String html, String filename) {
        try {
            final int width = 900;
            WebView imageView = new WebView(this);
            imageView.setBackgroundColor(Color.WHITE);
            imageView.getSettings().setJavaScriptEnabled(false);
            imageView.getSettings().setDefaultTextEncodingName("UTF-8");
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, 20000);
            imageView.setAlpha(0.01f);
            imageView.setTranslationX(-10000f);
            root.addView(imageView, lp);
            imageView.setWebViewClient(new WebViewClient() {
                private boolean handled = false;
                @Override public void onPageFinished(WebView view, String url) {
                    if (handled) return;
                    handled = true;
                    view.postDelayed(() -> view.evaluateJavascript(
                        "Math.max(document.body ? document.body.scrollHeight : 0, document.documentElement ? document.documentElement.scrollHeight : 0)", result -> {
                            try {
                                String raw = result == null ? "" : result.replace("\"", "").trim();
                                int measured = (int) Double.parseDouble(raw);
                                int height = Math.max(600, Math.min(12000, measured + 50));
                                view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
                                view.layout(0, 0, width, height);
                                view.postDelayed(() -> writeImageAndShare(view, width, height, filename), 200);
                            } catch (Exception e) {
                                Log.e("SAAD_DATA_IMAGE", "Failed to measure image content", e);
                                root.removeView(view); view.destroy(); shareFailure();
                            }
                        }), 150);
                }
                @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    Log.e("SAAD_DATA_IMAGE", "Image WebView error: " + description);
                    root.removeView(view); view.destroy(); shareFailure();
                }
            });
            imageView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Log.e("SAAD_DATA_IMAGE", "Unable to start image generation", e);
            shareFailure();
        }
    }

    private void writeImageAndShare(WebView view, int width, int height, String filename) {
        Bitmap bitmap = null;
        try {
            // Scale long documents to a WhatsApp-friendly image while preserving readability.
            float scale = Math.min(1f, 2200f / height);
            int outW = Math.max(1, (int) (width * scale));
            int outH = Math.max(1, (int) (height * scale));
            bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            canvas.save();
            canvas.scale(scale, scale);
            view.draw(canvas);
            canvas.restore();

            File dir = new File(getCacheDir(), "images");
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("Cannot create image cache directory");
            String safe = (filename == null ? "SAAD_DATA.png" : filename).replaceAll("[^a-zA-Z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".png")) safe += ".png";
            File out = new File(dir, safe);
            try (FileOutputStream stream = new FileOutputStream(out)) {
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw new java.io.IOException("PNG compression failed");
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/png");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, "SAAD DATA");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة الصورة عبر"));
        } catch (Exception e) {
            Log.e("SAAD_DATA_IMAGE", "Failed to write/share image", e);
            shareFailure();
        } finally {
            if (bitmap != null) bitmap.recycle();
            if (root != null) root.removeView(view);
            view.destroy();
        }
    }

    private void shareFailure() {
        new android.app.AlertDialog.Builder(this).setMessage("تعذر إنشاء ملف PDF. يرجى المحاولة مرة أخرى.").setPositiveButton("حسناً", null).show();
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("handleAndroidBack()", value -> { if (!"true".equals(value)) MainActivity.super.onBackPressed(); });
        else super.onBackPressed();
    }
}
