package com.saad.spice;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.pdf.PrintedPdfDocument;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.CancellationSignal;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new PdfBridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/"))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception ignored) { view.loadUrl(url); }
                    return true;
                }
                return false;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class PdfBridge {
        @JavascriptInterface public void sharePdf(String html, String filename) {
            handler.post(() -> createAndSharePdf(html, filename));
        }
    }

    private void createAndSharePdf(String html, String filename) {
        WebView pdfView = new WebView(this);
        pdfView.setBackgroundColor(Color.WHITE);
        pdfView.getSettings().setJavaScriptEnabled(false);
        int width = 794;
        pdfView.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(20000, View.MeasureSpec.AT_MOST));
        pdfView.layout(0, 0, width, 20000);
        pdfView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)", result -> {
                    try {
                        int height = Math.max(900, Math.min(20000, (int) Double.parseDouble(result.replace("\"", "")) + 50));
                        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, width, height);
                        writePdfAndShare(view, width, height, filename);
                    } catch (Exception e) { shareFailure(); }
                });
            }
        });
        pdfView.loadDataWithBaseURL("https://saaddata.local/", html, "text/html", "UTF-8", null);
    }

    private void writePdfAndShare(WebView view, int contentWidth, int contentHeight, String filename) {
        PdfDocument doc = new PdfDocument();
        try {
            final int pageW = 595, pageH = 842;
            float scale = (float) pageW / contentWidth;
            int pageCssHeight = (int) (pageH / scale);
            int pageCount = Math.max(1, (contentHeight + pageCssHeight - 1) / pageCssHeight);
            for (int n = 0; n < pageCount; n++) {
                PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, n + 1).create());
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);
                canvas.save();
                canvas.scale(scale, scale);
                canvas.translate(0, -n * pageCssHeight);
                view.draw(canvas);
                canvas.restore();
                doc.finishPage(page);
            }
            File dir = new File(getCacheDir(), "pdf");
            if (!dir.exists()) dir.mkdirs();
            String safe = (filename == null ? "SAAD_DATA.pdf" : filename).replaceAll("[^a-zA-Z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".pdf")) safe += ".pdf";
            File out = new File(dir, safe);
            try (FileOutputStream stream = new FileOutputStream(out)) { doc.writeTo(stream); }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, "SAAD DATA - PDF");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة ملف PDF عبر"));
        } catch (Exception e) { shareFailure(); }
        finally { doc.close(); view.destroy(); }
    }

    private void shareFailure() {
        new android.app.AlertDialog.Builder(this).setMessage("تعذر إنشاء ملف PDF. يرجى المحاولة مرة أخرى.").setPositiveButton("حسناً", null).show();
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("handleAndroidBack()", value -> { if (!"true".equals(value)) MainActivity.super.onBackPressed(); });
        else super.onBackPressed();
    }
}
